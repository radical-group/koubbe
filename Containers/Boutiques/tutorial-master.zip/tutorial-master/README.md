<img src="http://boutiques.github.io/images/logo.png" width="150" alt="Boutiques logo"/>

# Boutiques tutorial

[![Binder](https://mybinder.org/badge_logo.svg)](https://binder.conp.cloud/v2/gh/neurolibre/boutiques-tutorial/master?filepath=%2Fnotebooks%2Fboutiques-tutorial.ipynb)

Open the [tutorial notebook](https://nbviewer.jupyter.org/github/boutiques/tutorial/blob/master/notebooks/boutiques-tutorial.ipynb) and get started!
